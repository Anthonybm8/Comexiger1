default_app_config = 'Rendimiento.apps.RendimientoConfig'
