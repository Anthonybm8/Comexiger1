urlpatterns = [
    # ... otras rutas ...
    # path('api/usuarios/', api_views.listar_usuarios_api, name='api_listar_usuarios'),  # COMENTADA
]
